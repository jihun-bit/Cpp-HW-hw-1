class dept {
	int size;
	int* scores;
public:
	dept(int size) {
		this->size = size;
		scores = new int[size];
	}
	//dept(const dept& dept);
	~dept();
	int getSize() { return size; }
	void read();
	bool isOver60(int index);
};
