#include "detp.h"
#include<iostream>
using namespace std;

//dept::dept(const dept& dept) {
//	this->size = dept.size;
//	scores = new int[size];
//	for (int i = 0; i < size; i++) {
//		this->scores[i] = dept.scores[i];
//	}
//}
dept::~dept() {
	delete[] scores;
}

void dept::read() {
	cout << "10�� ���� �Է� >> ";
	for (int i = 0; i < size; i++) {
		cin >> scores[i];
	}
}
bool dept::isOver60(int index) {
	if (scores[index] > 60)
		return true;
	return false;
}